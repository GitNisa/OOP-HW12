// Homework #11: Serialization in Java.
// This program uses serialization. It asks the user for their name, phone number, DOB, and email
// and then updates information, deletes information, retrieves information from a file.
//
// Name: Nisa Khatoon

import java.io.FileInputStream; 
import java.io.FileOutputStream;
import java.io.ObjectInputStream; 
import java.io.ObjectOutputStream;
import java.util.ArrayList; 
import java.util.Scanner;

class Test {
	private static ArrayList < Person > personsinfo = new ArrayList < Person > ();
	private static Scanner scan = new Scanner (System.in);
	private static String fileName = "persons.txt";


  public static void addInformation () {
		
	  String Name;		
	  String PhoneNumber;		
	  String dob;			
	  String email;		 

      System.out.print ("\nEnter Full Name: ");
      Name = scan.nextLine ();

      System.out.print ("Enter Phone Number: ");
      PhoneNumber = scan.nextLine ();

      System.out.print ("Enter Date of Birth: ");
      dob = scan.nextLine ();

      System.out.print ("Enter Email Address: ");
      email = scan.nextLine ();

    Person prs = new Person (Name, PhoneNumber, dob, email);
    personsinfo.add (prs);		
    
    try {
    	FileOutputStream filestream = new FileOutputStream (fileName);
    	ObjectOutputStream objectstream = new ObjectOutputStream (filestream);
        objectstream.writeObject (personsinfo);
        objectstream.close ();
        filestream.close (); }
    
    catch (Exception ex) {
      System.out.println ("ERROR! " + ex); }
    }				
  
  public static void display () {
	  
	  try {
		  FileInputStream fileinputstream = new FileInputStream (fileName);
		  ObjectInputStream objectinputstream = new ObjectInputStream (fileinputstream);
		  ArrayList < Person > persons = (ArrayList < Person >) objectinputstream.readObject ();
		  objectinputstream.close ();
		  fileinputstream.close ();
		  
		  System.out.printf ("%4s %15s %24s %15s %20s\n", "ID", "Name", "Phone Number", 
				  "DOB", "Email");  
		  int i = 0;
		  
		  for (Person prs2:persons){
			  System.out.printf ("%3d %23s %15s %20s %25s\n", prs2.getID (),
					  prs2.getName (), prs2.getPhoneNumber (), prs2.getDob (), prs2.getEmail ()); 
			  i++; }
		  }
	  
	  catch (Exception ex) {
      System.out.println ("ERROR! " + ex); }
	  }
  
  public static void deleteInformation () {
	  display ();
	  System.out.print ("\nEnter the ID number that you want to delete: ");
	  int id = scan.nextInt ();
	  scan.nextLine ();
	  
	  int index = 0;
	  for (index = 0; index < personsinfo.size (); index++) {
		  if (personsinfo.get (index).getID () == id) {
			  personsinfo.remove (index);
			  break; }
		  } 
	  
	  if (index == personsinfo.size ()) {
	System.out.println ("ID number " + id + " doesn't exist");
	return; }
	  System.out.println (id + " Deletion complete");
	  
	  try {
		  FileOutputStream filestream = new FileOutputStream (fileName);
		  ObjectOutputStream objectstream = new ObjectOutputStream (filestream);
		  objectstream.writeObject (personsinfo);
		  objectstream.close ();
		  filestream.close (); }
	  
	  catch (Exception ex) {
      System.out.println ("ERROR! " + ex); }
	  
	  try {
     int i = 0; 
	  
    for (Person p:personsinfo) {
	  System.out.printf ("%5d %20s %15s %10s %20s \n", p.getID (), p.getName (),
			  p.getPhoneNumber (), p.getDob (), p.getEmail ());
	  i++; }
    }
	  
	  catch (Exception ex) {
      System.out.println ("ERROR!" + ex); }
	  }			
  
  public static void updateInformation () {
    display ();
    System.out.print ("\nPlease enter the person's ID number to update the information: ");
    int id = scan.nextInt ();
    scan.nextLine ();
    
    int index = 0;
    for (index = 0; index < personsinfo.size (); index++) {
	if (personsinfo.get (index).getID() == id) {
	    System.out.print ("Updated Full Name: ");
	    String name = scan.nextLine ();
	    personsinfo.get (index).setName (name);

	    System.out.print ("Updated Phone Number: ");
	    String PhoneNumber = scan.nextLine ();
	    personsinfo.get (index).setPhone_Number (PhoneNumber);

	    System.out.print ("Updated Date of Birth: ");
	    String dob = scan.nextLine ();
	    personsinfo.get (index).setDob (dob);

	    System.out.print ("Updated Email Address: ");
	    String email = scan.nextLine ();
	    personsinfo.get (index).setEmail (email);
	    break; }
	}
    
    if (index == personsinfo.size ()) {
	System.out.println (id + " does not exist");
	return; }
    System.out.println (id + " update is complete");
    
    try {
    	FileOutputStream filestream = new FileOutputStream (fileName);
    	ObjectOutputStream objectstream = new ObjectOutputStream (filestream);
    	objectstream.writeObject (personsinfo);
    	objectstream.close ();
    	filestream.close (); }
    
    catch (Exception ex) {
      System.out.println ("ERROR!" + ex); }
    
    try {
      System.out.println ("file information after updating - ");
      System.out.printf ("%5s %15s %24s %15s %20s\n", "ID", "Name",
			 "Phone Number", "DOB", "E mail");
      int i = 0;
      
      for (Person p:personsinfo) {
	  System.out.printf ("%3d %21s %19s %15s %25s\n", p.getID (),
			     p.getName (), p.getPhoneNumber (), p.getDob (), p.getEmail ()); 
	  i++; }
      }
    
    catch (Exception ex) {
      System.out.println ("ERROR!" + ex); } 
    }
  
  public static void main (String[]args) {
    char choice;
    
    do {
	System.out.println ("\n         MENU\n");
	System.out.println ("1) Add Information into file");
	System.out.println ("2) Retrieve Information from a file and display");
	System.out.println ("3) Delete Information");
	System.out.println ("4) Update Information");
	System.out.println ("5) Exit");
	System.out.print ("Please select an option:  ");
	choice = scan.next ().charAt (0);
	scan.nextLine ();	
	
	switch (choice) {
	  case '1':
	    addInformation ();
	    break;
	    
	  case '2':
	    display ();
	    break;
	    
	  case '3':
	    deleteInformation ();
	    break;

	  case '4':
	    updateInformation ();
	    break;

	  case '5':
	    System.out.println ("-----ENDED-----");
	    break;

	  default:
	    System.out.println ("Please select an option: ");
	    break; }
	}
    
    while (choice != '5'); }
  }	



