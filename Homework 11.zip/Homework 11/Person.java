
import java.io.*;


public class Person implements Serializable {
  private static int count = 0;	
  private int id;		
  private String name;		
  private String Phonenumber;	          
  private String dob;		
  private String email;		
  
  public Person (String name, String phoneNumber, String dob, String email) {
    this.id = count + 1;
    this.name = name;
    this.Phonenumber = phoneNumber;
    this.dob = dob;
    this.email = email;
    count++; }	
  
  public int getID () {
    return id; }			
  
  public String getName () {
    return name; }
  
  public String getPhoneNumber () { 
    return Phonenumber; }
  
  public String getDob () {
    return dob; }
  
  public String getEmail () {
    return email; }

  public void setName (String name) {
    this.name = name; }
  
  public void setPhone_Number (String phoneNumber) {
    this.Phonenumber = phoneNumber; }
  
  public void setDob (String dob) {
    this.dob = dob; }
  
  public void setEmail (String email) {
    this.email = email; }
  
  public String toString () {
    return "Name: " + name + ", Phone Number : " + Phonenumber + ", Date of Birth: " 
  + dob + ", email: " + email; }
  
}

